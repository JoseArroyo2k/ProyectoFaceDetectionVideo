import cv2 
from video_controller import video_controller
class detection_face(object):
    def Detection(video_path):
        face_cascade = cv2.CascadeClassifier('C:/Users/Antuanet/Downloads/ironman2021_PyQt5_photoshop-main/day25_video_player_project/haarcascade_frontalface_default.xml') 
        eye_cascade = cv2.CascadeClassifier('C:/Users/Antuanet/Downloads/ironman2021_PyQt5_photoshop-main/day25_video_player_project/haarcascade_eye.xml') 

        # Selecciona el archivo de video
        # video_path = 'path/to/your/video/file.mp4'
        cap = cv2.VideoCapture(video_path)

        # Verifica si la apertura del video fue exitosa
        if not cap.isOpened():
            print("Error: No se pudo abrir el archivo de video.")
            return -1

        face_count = 0  # Inicializa el contador de caras
        ###
        #if video_controller.play==True:
            ###
        while True :####modifique and video_controller.play==True
                # Lee un fotograma del video
            ret, img = cap.read()

            if not ret:
                print("Fin del video.")
                break

                # Convierte el fotograma a escala de grises
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

                # Detecta caras en el fotograma
            faces = face_cascade.detectMultiScale(gray, 1.3, 5)

                # Incrementa el contador de caras por cada cara detectada en el fotograma
            face_count += len(faces)

            for (x, y, w, h) in faces:
                # Dibuja un rectángulo alrededor de la cara
                cv2.rectangle(img, (x, y), (x+w, y+h), (255, 255, 0), 2)
                roi_gray = gray[y:y+h, x:x+w]
                roi_color = img[y:y+h, x:x+w]

                    # Detecta ojos en la región de la cara
                eyes = eye_cascade.detectMultiScale(roi_gray)

                    # Dibuja un rectángulo alrededor de los ojos
                for (ex, ey, ew, eh) in eyes:
                    cv2.rectangle(roi_color, (ex, ey), (ex+ew, ey+eh), (0, 127, 255), 2)

                # Muestra el fotograma en una ventana
                cv2.imshow('Video', img)
                
                # Espera la tecla 'q' para salir del bucle
                #if cv2.waitKey(1) & 0xFF == ord('q'):
                #    break
                if video_controller.stop==True:
                    break
            #####    
        #if video_controller.pause==True or video_controller.stop==True:



        #####
        # Libera los recursos y cierra la ventana
        cap.release()
        cv2.destroyAllWindows()

        # Devuelve el número total de caras detectadas
        return face_count

